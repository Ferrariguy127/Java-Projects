import java.util.*;
//David Bulin
//10/20/2023
//Stack Practice for Lab 7
import java.util.EmptyStackException;
// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Stack<Character> S = new Stack<Character>();
        Scanner sc = new Scanner(System.in);
        boolean hasParenthesis = false;
        System.out.println("Please enter the equation to be evaluated. ");
        String formula = sc.nextLine();

        for (int i=0; i<formula.length(); i++) {
            char q = formula.charAt(i);
            //char q2 = 0;
            if (q == '(' || q == '{' || q == '[') {
                S.push(q);
                hasParenthesis = true;
            } else
                if (q == ')' || q == '}' || q == ']') {//compares the current iteration value q against the stack, if q is the closing set of stack S then it pops off the stack.
                    if (S.peek()=='('&& q==')')
                        S.pop();
                    else if (S.peek()=='['&& q==']')
                        S.pop();
                    else if (S.peek()=='{'&& q=='}')
                        S.pop();

            }
        }
        if (!hasParenthesis) {
            System.out.println("No parenthesis");
        }
        else if (S.isEmpty())
            System.out.println("Balanced");
        else System.out.println("Unbalanced");

        }
    }