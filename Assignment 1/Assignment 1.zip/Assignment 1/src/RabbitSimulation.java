import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
//This one should overtake main or may need to be moved into main for functionality.
public class RabbitSimulation {
    private static final int Trial_Count = 10;//number of trials to be preformed
    private static final int Total_Days = 365;//total number of days in the year. also the limit in which the trial should stop running


    public static void main(String[] args) {
        ArrayList<int[]> TrialData = new ArrayList<>();
        try {
            Scanner sc = new Scanner(new File("Seeds.txt"));
            while (sc.hasNextLine()) {
                int Does = sc.nextInt();
                int Bucks = sc.nextInt();
                System.out.println(Does);
                System.out.println(Bucks);

                int[] TrialResults = StartRun(Does, Bucks);
                TrialData.add(TrialResults);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        PrintTrialResults(TrialData);
        PrintDeviation(TrialData);
    }

    private static int[] StartRun(int Does, int Bucks) {
        ArrayList<Rabbit> Rabbits = new ArrayList<>();
        //for (int i = 0; i < Does; i++) {
            //Rabbits.add(new Rabbit(true));
        //}
        for (int i = 0; i < Bucks; i++) {
            Rabbits.add(new Rabbit(false));
        }
        for (int day = 0; day <= Total_Days; day++) {
            for (Rabbit rabbit : Rabbits) {
                Rabbit.incrementAge();
                if (rabbit.isFemale() && rabbit.getAge() >= 100 && !rabbit.isPregnant() && rabbit.getDaysAfterDelivery() >= 7) {
                    rabbit.setPregnant();
                }
                if (rabbit.isPregnant() && rabbit.getDaysAfterDelivery() >= 7) {
                    int Littersize = rabbit.giveBirth();
                    for (int i = 0; i < Littersize; i++) {
                        Rabbits.add(new Rabbit(true));
                    }
                }
            }
        }
        int[] result = new int[3];
        result[0] = Rabbits.size();
        result[1] = NumberOfFemales(Rabbits);
        result[2] = NumberOfMales(Rabbits);
        return result;
    }





    private static int NumberOfFemales(ArrayList<Rabbit> rabbits) {
        int count = 0;
        for (Rabbit rabbit : rabbits) {
            if (rabbit.isFemale()) {
                count++;
            }
        }
        return count;
    }

    private static int NumberOfMales(ArrayList<Rabbit> rabbits) {
        int count = 0;
        for (Rabbit rabbit : rabbits) {
            if (!rabbit.isFemale()) {
                count++;
            }
        }
        return count;
    }

    private static void PrintTrialResults(ArrayList<int[]> TrialData) {
        int Trial_Count = 0;
        for (int[] result : TrialData) {
            System.out.println("Starting with " + result[1] + " Does and " + result[2] + " Bucks:");
            for (int i = 0; i < Trial_Count; i++) {
                System.out.println("Trial " + TrialData + ": " + result[0] + " was the final population of rabbits; " + result[1] + " does, " + result[2] + " bucks. ");
                Trial_Count++;
            }
        }
    }
    private static void PrintDeviation(ArrayList<int[]> TrialData) {
        double TotalRabbits = 0;
        double TotalFemales = 0;
        double TotalMales = 0;

        for (int[] result : TrialData) {
            TotalRabbits += result[0];
            TotalFemales += result[1];
            TotalMales += result[2];
        }
        double AvgRabbits = TotalRabbits / TrialData.size();
        double AvgFemales = TotalFemales / TrialData.size();
        double AvgMales = TotalMales / TrialData.size();

        double sumSquaredDeviationOfRabbits = 0;
        double sumSquaredDeviationsOfFemales = 0;
        double sumSquaredDeviationsOfMales = 0;

        for (int[] result : TrialData) {
            sumSquaredDeviationOfRabbits += Math.pow(result[0] - AvgRabbits, 2);
            sumSquaredDeviationsOfFemales += Math.pow(result[1] - AvgFemales, 2);
            sumSquaredDeviationsOfMales += Math.pow(result[2] - AvgMales, 2);
        }
        double StandardDeviationOfRabbits = Math.sqrt(sumSquaredDeviationOfRabbits / TrialData.size());
        double StandardDeviationOfFemales = Math.sqrt(sumSquaredDeviationsOfFemales / TrialData.size());
        double StandardDeviationOfMales = Math.sqrt(sumSquaredDeviationsOfMales / TrialData.size());

    }
}
            //going to need to add something like
            //for (days <365; days++)
            //update values for rabbit totals, rabbit age,
            //rabbits cannot become pregnant if less than 100 days of age
            //rabbits need 7 days to pass before becoming pregnant again.
            //in order to become pregnant the rabbits need to be >100 days old !pregnant
            //
            //