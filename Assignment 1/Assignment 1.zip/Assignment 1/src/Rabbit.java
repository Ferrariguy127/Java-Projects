import java.util.Random;

public class Rabbit {

    //sex
    private static final int MIN_GESTATION_DAYS = 28;
    private static final int MAX_GESTATION_DAYS = 32;
    private static final int MIN_LITTER_SIZE = 3;
    private static final int MAX_LITTER_SIZE = 8;
    // can breed at 100 days old
    //50/50 chance of being male or female rabbit
    //is pregnant is boolean
    private boolean isFemale;
    private static int age;
    private static boolean isPregnant;
    private static int gestationPeriod;
    private static int daysInGestation;
    private static int daysAfterDelivery;

    //how long is pregnant for
    //if rabbit is female is it mature enough to breed
    //if rabbit is pregnant set gestation to rant.int(28-32 days)
    //constructor
    public Rabbit(boolean isFemale) {
        this.isFemale = isFemale;
        this.age = 0;
        this.isPregnant = false;
        this.gestationPeriod = getRandomGestationPeriod();
        this.daysInGestation = 0;
        this.daysAfterDelivery = 7; //counts down from 7 til it becomes pregnant again
    }

    private int getRandomGestationPeriod() {
        return new Random().nextInt(MAX_GESTATION_DAYS - MIN_GESTATION_DAYS + 1) + MIN_GESTATION_DAYS;
    }

    public boolean isFemale() {
        return isFemale;
    }

    public int getAge() {
        return age;
    }

    public static void incrementAge() {
        age++;
        if (isPregnant) {
            daysInGestation++;
            if (daysInGestation >= gestationPeriod) {
                daysInGestation = 0;
                daysAfterDelivery = 0;
                isPregnant = false;
            }
        } else if (daysAfterDelivery >= 0) {
            daysAfterDelivery++;
        }
    }

    public boolean isPregnant() {
        return isPregnant;
    }

    public void setPregnant() {
        isPregnant = true;
    }

    public int getDaysAfterDelivery() {
        return daysAfterDelivery;
    }

    public void setDaysAfterDelivery(int daysAfterDelivery) {
        this.daysAfterDelivery = daysAfterDelivery;
    }

    public int giveBirth() {
        return new Random().nextInt(MAX_LITTER_SIZE - MIN_LITTER_SIZE + 1) + MIN_LITTER_SIZE;
    }
}

//TA said to try and find or write a code that will update all values for the rabbit attributes in a set for loop. When there is a total
//number of rabbits being updated around 200-400ish it should have decent program features.