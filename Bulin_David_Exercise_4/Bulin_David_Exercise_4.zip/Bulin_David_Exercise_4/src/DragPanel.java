import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class DragPanel extends JPanel {

    ImageIcon image = new ImageIcon("smiley.png");
    final int WIDTH = image.getIconWidth();
    final int HEIGHT = image.getIconHeight();
    Point ImageCorner;
    Point prevPT;

    DragPanel() {
        ImageCorner = new Point(0,0);
        setBackground(Color.red);
        ClickListener clickListener = new ClickListener();
        DragListener dragListener = new DragListener();
        this.addMouseListener(clickListener);
        this.addMouseMotionListener(dragListener);
    }

        public void paintComponent(Graphics g){
        super.paintComponent(g);
        image.paintIcon(this,g, (int)ImageCorner.getX(),(int)ImageCorner.getY());

        }

        private class ClickListener extends MouseAdapter{

            public void mousePressed(MouseEvent e){
                prevPT = e.getPoint();

            }
        }
        private class DragListener extends MouseMotionAdapter{

            public void mouseDragged(MouseEvent e){

                Point currentPt = e.getPoint();
            if(currentPt.getX() < 600 && currentPt.getY() < 600){
                ImageCorner.translate(
                        (int)(currentPt.getX() -prevPT.getX()),
                        (int)(currentPt.getY()-prevPT.getY())
                );}
            else if(currentPt.getX() > 600 || currentPt.getY() > 600 ){
                ImageCorner = new Point(0, 0);}

                prevPT = currentPt;
                repaint();
            }


        }
    }

