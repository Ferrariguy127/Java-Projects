//David D Bulin,
//Assignment 5 BST Comparisons
//November 13 2023
//these nodes are for navigating through the methods. Pulled from the exercise in class on thursday.

class Node {
    int data;
    Node left, right;

    public Node(int item) {
        data = item;
        left = right = null;
    }
}