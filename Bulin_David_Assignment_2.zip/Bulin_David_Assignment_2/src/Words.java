public class Words {
    String word;
    int value;

    public Words(String word, int value){
        this.word = word;
        this.value = value;
    }
    //function to return the word value of a Words object
    public String toString() {
        return word + " " + value + "\n";
    }

    public int getValue() {
        return value;
    }
}
