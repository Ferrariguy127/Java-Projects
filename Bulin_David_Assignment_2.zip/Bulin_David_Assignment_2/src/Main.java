import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.io.PrintWriter;

//David Bulin
//Assignment 2
//Date 10/12/2023
//This code will take the text given in two different documents and compare them
//Returning the values of each duplicated word

public class Main {
    public static void main(String[] args) throws FileNotFoundException {

        // Create ArrayLists to hold the contents of the text files
        ArrayList<String> speechWords = new ArrayList<>();
        ArrayList<String> stopWords = new ArrayList<>();


        // Read black_lives_matter_espy_speech.txt file and add words to speechWords ArrayList
        try {
            File speechFile = new File("black_lives_matter_espy_speech.txt");
            Scanner speechReader = new Scanner(speechFile);
            while (speechReader.hasNext()) {
                speechWords.add(speechReader.next());
            }
            speechReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("Speech file not found.");
        }

        //this turns the string into lowercase and removes the punctuation
        for (int i = 0; i < speechWords.size(); i++) {
            speechWords.set(i, speechWords.get(i).toLowerCase());
        }
        String modify = speechWords.toString();
        modify = modify.replaceAll("\\p{Punct}", "");
        String[] array = modify.split(" ");
        ArrayList<String> list = new ArrayList<>(Arrays.asList(array));

        //modifiedspeech;
        ArrayList<String> modifiedspeech = new ArrayList<>(list);
        for (String word : stopWords) {
            if (modifiedspeech.contains(word)) {
                modifiedspeech.remove(word);
            } else {
                continue;
            }
        }

        ArrayList<String> uniqueModifiedWords = new ArrayList<>();
        for (String word : modifiedspeech) {
            if (uniqueModifiedWords.contains(word)) {
                continue;
            } else {
                uniqueModifiedWords.add(word);
            }
        }


        //uniquecount takes the number of unique words from the speech and prints stores it in an arrayList
        ArrayList<String> uniquecount = new ArrayList<>();
        for (String word : list) {
            if (uniquecount.contains(word)) {
                continue;
            } else {
                uniquecount.add(word);
            }


        }
        //goes through each speech comparing the two words to figure out how many times each word is counted
        ArrayList<Words> WordsArrayList = new ArrayList<Words>();
        for (String word : uniqueModifiedWords ) {
            int t = 0;
            for (String word2 : list) {
                if (word.equals(word2)) {
                    t++;
                }

            }
            WordsArrayList.add(new Words(word, t));
        }
        //sort arraylist in descending order
        //This function uses comparator to create a sorting method that compares both of the numbers
        //if the number is higher it puts it above the next number
        Comparator DescendingComparator = new Comparator<Words>() {
            public int compare(Words n1, Words n2) {
                return n2.getValue()-n1.getValue();
            }
        };
Collections.sort(WordsArrayList, DescendingComparator);
        System.out.println(WordsArrayList);
        // Read common_stop_words.txt file and add words to stopWords ArrayList
                try {
                    File stopFile = new File("common_stop_words.txt");
                    Scanner stopReader = new Scanner(stopFile);
                    while (stopReader.hasNext()) {
                        stopWords.add(stopReader.next());
                    }
                    stopReader.close();
                } catch (FileNotFoundException e) {
                    System.out.println("Stop words file not found.");
                }


                // Display total number of words in the speech file

                System.out.println("Total number of words in the black_lives_matter_espy_speech.txt speech is : " + speechWords.size());
                System.out.println("Total number of words in the common_stop_words.txt file is " + stopWords.size());
                System.out.println("Total number of unique words in the black_lives_matter_espy_speech.txt speech is : " + uniquecount.size());
                System.out.println("Total number of words in the modified black_lives_matter_espy_speech.txt speech is : " + modifiedspeech.size());
                System.out.println("Total number of unique words in the modified black_lives_matter_espy_speech.txt speech is : " + WordsArrayList.size());

                //this bottom function will output the results to the document A2_Word_Cloud.txt
                File path = new File("A2_Word_Cloud.txt");
                PrintWriter pw = new PrintWriter(path);
                for(int i = 0; i < 100; i++){
                    pw.write(WordsArrayList.get(i).toString());
                }
                pw.flush();
                pw.close();
            }
        }