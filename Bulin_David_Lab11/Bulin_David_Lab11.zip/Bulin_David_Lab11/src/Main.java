//David Bulin
//Lab 11
//November 17th 2023
public class Main {
    public static void main(String[] args) {

        new MyFrame();
    }
}