import java.util.*;
public class Main {
    public static void main(String[] args) {
        int N=5;
        LinkedList HotPotato = new LinkedList();
        Iterator M = HotPotato.iterator();
        for (int i=1; i<=N; i++)
            HotPotato.add(i);

        while (HotPotato.size()>1){
            for (int i=0; i<N-1; i++){
                M.next();
            }
            M.remove();
            if (M.hasNext()){
                M.next();
            }
            else
            {
                M = HotPotato.listIterator();
            }
        }


        System.out.println("Player " + HotPotato.get(0) + "wins");
    }
}