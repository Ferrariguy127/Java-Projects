public interface Shape{
    abstract double area();
    abstract double perimeter();
    abstract double sumOfInteriorAngles();

}
