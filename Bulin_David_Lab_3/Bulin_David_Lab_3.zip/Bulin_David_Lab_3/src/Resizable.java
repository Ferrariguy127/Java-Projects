public interface Resizable {
    //resizes the value of x
    void resize(float x);
}